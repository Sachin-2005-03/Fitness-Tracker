package com.fitnesstracker.fitnessworld.constant;
public enum Role{
    USER,ADMIN
}
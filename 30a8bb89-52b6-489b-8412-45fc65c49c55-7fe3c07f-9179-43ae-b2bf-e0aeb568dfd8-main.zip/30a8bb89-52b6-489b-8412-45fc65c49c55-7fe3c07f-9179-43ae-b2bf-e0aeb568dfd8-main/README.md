# 30a8bb89-52b6-489b-8412-45fc65c49c55-7fe3c07f-9179-43ae-b2bf-e0aeb568dfd8
Repository for Teams Project code and project management
